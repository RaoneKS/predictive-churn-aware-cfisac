# CFISAC Reproducibility Package

## Research project

Predictive Churn-Aware Overlapping User- and Target-Centric Clustering
for Mobile Cell-Free ISAC Networks.

Repository:
https://github.com/RaoneKS/predictive-churn-aware-cfisac

Research branch:
pdf-compliance-extension

## Contents

- Tracked project files exported from the recorded Git commit.
- Python simulation source and project configuration.
- Multi-seed experiment runner:
  experiments/run_multiseed_thresholds_fixed.py
- Threshold-wiring regression test:
  tests/test_threshold_wiring.py
- Research paper draft and validation documentation.
- Corrected simulation results, figures, per-seed summaries,
  block-level metrics, decision traces, and experiment metadata.

The experiment runner was copied from the working tree as a
supplementary, untracked file. The threshold-wiring regression test is
tracked in Git and is included in the source snapshot.

## Software setup

Use Python and a virtual environment. From this directory:

    python -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt pytest

Run the test suite:

    PYTHONPATH=. pytest -q

The project test suite was previously verified with 377 passed and
11 subtests passed. This is a recorded result, not a claim that the
tests have been rerun on every recipient's machine.

## Reproducing the multi-seed comparison

Run from the project root:

    python experiments/run_multiseed_thresholds_fixed.py

The experiment uses seeds 42 through 51, four policies, and 100 time
blocks per policy/seed combination. It is expected to generate 40
simulations and 4,000 block-level rows.

The runner creates:

    results/multiseed_comparison_thresholds_fixed_20261013/

It intentionally refuses to overwrite an existing output directory.
If that directory already exists, use a fresh copy or a separate
working directory before running the experiment.

The runner requires the configuration at:

    configs/default.yaml

The SHA-256 of that configuration in the supplied project was:

    53912d3ecbb4dfc2cbae5eecb85d3cadb8fd7c7168d307e0e72a798eac9ad4b5

## Results already included

The folder
results/professor_submission_corrected_20261013/
contains the corrected results from the completed experiment.

Its metadata records:
- 10 seeds: 42–51
- 4 policies: STATIC, REACTIVE, PREDICTIVE, PREDICTIVE+CHURN
- 100 time blocks per simulation
- 40 completed simulations
- 4,000 block-level rows

The existing results are provided as recorded evidence. Their inclusion
does not imply that the experiment has been independently rerun from
this package.

## Source and result provenance

The source snapshot in this package is based on the Git commit recorded
in SOURCE_PROVENANCE.txt.

The included experiment metadata records an earlier commit,
370136bdb906c364da4bc3b08a4208517fe52150, and indicates that the source
working tree was modified when the experiment was run.

Therefore, the included results must not be represented as having been
generated from the package's current Git snapshot without an independent
rerun. The configuration hash and original metadata are retained for
auditability.

## Metric interpretation and limitations

- QoS and tracking violation fields represent violation magnitudes,
  not counts of violating users, targets, or blocks.
- The energy metric is a simulation-model metric, not a physical
  measurement of hardware power.
- Differences across the included ten seeds are descriptive results.
  They should not be presented as statistically significant without
  appropriate statistical analysis.
- The included results do not establish universal hard-feasibility
  guarantees or independently verified hardware performance.

Review docs/REPRODUCIBILITY.md, docs/RESULTS_AND_VALIDATION.md,
docs/RESEARCH_PAPER_DRAFT.md, and the included results report before
making research or publication claims.
